import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class CartService {
  // private baseUrl = 'http://localhost:8088/cart/insertcart'; 

  constructor(private http: HttpClient) {}

  getAllItemsOfCart(uid:any):Observable<any> {
    const url = 'http://localhost:8088/cart/all/'+uid;
    return this.http.get(url);
  }

  addToCart(cartItems:any):Observable<any> {
    const url = 'http://localhost:8088/cart/insertcart';
    return this.http.post(url,cartItems);
  }

}
