import { Component, OnInit } from '@angular/core';
import { CartService } from './cart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
})
export class CartComponent implements OnInit {
  cartDetails: any; 
  constructor(private cartService: CartService) {}

  cartData:any;
  ngOnInit() {
    this.getCartData();
  }

  getCartData() {
    const id = window.localStorage.getItem('id');
    this.cartService.getAllItemsOfCart(id).subscribe((res)=>{
      console.log(res);
      this.cartData = res;
    });
  }
}





