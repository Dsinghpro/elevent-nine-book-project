import { Component } from '@angular/core';
import { BookService } from '../book/book.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class CustomerHomepageComponent {
  title: string = '';
  category:string='';
  searchResults: any[] = [];

 

  constructor(private bookservice:BookService,private router:Router) {}

  search(){
    this.router.navigate(['/search'])

  }

  searchBooksByTitle() {
    if (this.title.trim() !== '') {
      this.bookservice.searchBooksByTitle(this.title).subscribe((data) => {
        this.searchResults = data;
      });
    }
  }

  searchBooksByCategory(){
    if (this.category.trim() !== '') {
      this.bookservice.searchBooksByCategory(this.category).subscribe((data) => {
        this.searchResults = data;
      });
    }
  }
}
