import { Component } from '@angular/core';
import { BookService } from '../book/book.service';
import { Router } from '@angular/router';
import { CustomerService } from '../customerdetails/customerdetails.service';
import { CartService } from '../cart/cart.service';


@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class CustomerHomepageComponent {

  input:string='';
  searchResults: any[] = [];
  
 

  constructor(private bookservice:BookService, private router:Router,private cartService:CartService) {}

  ngOnInit(): void {
    this.getBooks();
  }

  search(){
    this.router.navigate(['/search'])
  }

  searchBooks(){
    if (this.input.trim() !== '') {
      this.bookservice.searchBooks(this.input).subscribe((data) => {
        this.searchResults = data;
      });
    }
  }

  getBooks() {
    this.bookservice.getBooks().subscribe((data) => {
        this.searchResults = data;
      });
  }
  redirecttofirst()

  {
   
    window.localStorage.removeItem('id');

    this.router.navigate(['/home'])


  }

  profile()
  {
    this.router.navigate(['/profile'])
  }

  cart(bookId:any){
    const data = {
      "bookID":bookId,
      "Custid":window.localStorage.getItem('id')
    }

    console.log(data);

    this.cartService.addToCart(data).subscribe();
    window.alert('added to cart');

  }

  goToCart() {
    this.router.navigateByUrl('/cart');
  }

}

  /*searchBooksByTitle() {
    if (this.title.trim() !== '') {
      this.bookservice.searchBooksByTitle(this.title).subscribe((data) => {
        this.searchResults = data;
      });
    }
  }

  searchBooksByCategory(){
    if (this.category.trim() !== '') {
      this.bookservice.searchBooksByCategory(this.category).subscribe((data) => {
        this.searchResults = data;
      });
    }
  }

  getBooks() {
    this.bookservice.getBooks().subscribe((data) => {
        this.searchResults = data;
      });
  }
  redirecttofirst()

  {

    this.router.navigate(['/home'])

  }
}*/
