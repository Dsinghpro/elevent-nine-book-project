import { Component } from '@angular/core';
import { BookService } from '../book/book.service';
import { Router } from '@angular/router';
import { CustomerService } from '../customerdetails/customerdetails.service';


@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class CustomerHomepageComponent {

  input:string='';
  searchResults: any[] = [];
  searchResult: any[] = [];
 

  constructor(private bookservice:BookService,private customerService:CustomerService, private router:Router) {}

  ngOnInit(): void {
    this.getBooks();
  }

  search(){
    this.router.navigate(['/search'])
  }

  searchBooks(){
    if (this.input.trim() !== '') {
      this.bookservice.searchBooks(this.input).subscribe((data) => {
        this.searchResults = data;
      });
    }
  }

  getBooks() {
    this.bookservice.getBooks().subscribe((data) => {
        this.searchResults = data;
      });
  }
  redirecttofirst()

  {

    this.router.navigate(['/home'])

  }

  getCustomer(){
    const id = window.localStorage.getItem('id');
    this.customerService.getCustomer(id).subscribe((data) =>{
      this.searchResult=data;
      console.log('iser -------------------->  '+JSON.stringify(data))
    });
  }
}

  /*searchBooksByTitle() {
    if (this.title.trim() !== '') {
      this.bookservice.searchBooksByTitle(this.title).subscribe((data) => {
        this.searchResults = data;
      });
    }
  }

  searchBooksByCategory(){
    if (this.category.trim() !== '') {
      this.bookservice.searchBooksByCategory(this.category).subscribe((data) => {
        this.searchResults = data;
      });
    }
  }

  getBooks() {
    this.bookservice.getBooks().subscribe((data) => {
        this.searchResults = data;
      });
  }
  redirecttofirst()

  {

    this.router.navigate(['/home'])

  }
}*/
