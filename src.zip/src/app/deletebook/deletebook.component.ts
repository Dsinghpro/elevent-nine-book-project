import { Component } from '@angular/core';
import { DeleteBookService } from './deletebook.service';
import { BookService } from '../book/book.service';

@Component({
  selector: 'app-deletebook',
  templateUrl: './deletebook.component.html',
  styleUrls: ['./deletebook.component.css']
})
export class DeletebookComponent {
  bookId: number=0;
  books:any[]=[];
  
  
  constructor(private deleteBookService: DeleteBookService) {}

  

  deleteBook(bookId: number) {
    if (!bookId) {
      console.error('No book selected to delete.');
      return;
    }
  
    this.deleteBookService.deleteBookById(bookId).subscribe(
      () => {
        console.log('Book deleted successfully');
        // Perform any additional actions here after successful deletion.
      },
      (error) => {
        console.error('Error deleting book:', error);
        // Handle the error appropriately.
      }
    );
  }
  
}