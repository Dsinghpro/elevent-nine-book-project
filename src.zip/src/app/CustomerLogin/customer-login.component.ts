import { Component } from '@angular/core';

import { CustomerLoginService } from './customer-login.service';

import { Router } from '@angular/router';



@Component({

  selector: 'app-customer-login',

  templateUrl: './customer-login.component.html',

  styleUrls: ['./customer-login.component.css']

})

export class CustomerLoginComponent {
      
 

 

  constructor(private loginService: CustomerLoginService,private router:Router) {}

  redirectToHomePage(Mobile_No:string,Password:string)
    {
        this.loginService.loginHere(Mobile_No, Password).subscribe(
            (response) => {
              if(response==1){
                this.router.navigate(['/customerhomepage'])
              }
              else{
                alert("NOT VALID")
              }
             },
       
             (error) =>
       
             {
       
               console.log("login n")       
             }
       
           )
           
    }
    redirectToSignIn()
    {
        this.router.navigate(["/sign-in"])
    }


  

}

 