import { Component } from '@angular/core';
import { CustomerService } from './customerdetails.service';

@Component({
  selector: 'app-customerdetails',
  templateUrl: './customerdetails.component.html',
  styleUrls: ['./customerdetails.component.css']
})
export class CustomerdetailsComponent {
  searchResults: any[] = [];
 
  constructor(private customerService:CustomerService) {}

  ngOnInit(): void {
    this.getCustomers();
  }

  getCustomers() {
    this.customerService.getCustomers().subscribe((data) => {
        this.searchResults = data;
      });
  }

}
