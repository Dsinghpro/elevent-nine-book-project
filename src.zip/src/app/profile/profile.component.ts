import { Component } from '@angular/core';
import { ProfileService } from './profile.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent {
  searchResult:any[]=[];
  constructor(private profileService:ProfileService){}
  getCustomer(){
    const id = window.localStorage.getItem('id');
    this.profileService.getCustomer(id).subscribe((data) =>{
      this.searchResult=data;
      console.log('user -------------------->  '+JSON.stringify(data))
    });
  }
}
