import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customerdetails/customerdetails.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit{
  profile:any[]=[];
  constructor(private customerService:CustomerService){}


  ngOnInit() {
    this.getCustomer();
  }

  getCustomer(){
    const id = window.localStorage.getItem('id');
    this.customerService.getCustomer(id).subscribe((data) =>{
      this.profile=data;
    });
  }
}


