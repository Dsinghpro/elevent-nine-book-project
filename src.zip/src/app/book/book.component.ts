import { Component } from '@angular/core';
import { BookService } from './book.service';
import { NgForm } from '@angular/forms'; 

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent {
  title: string = '';
  category:string='';
  input:string='';
  searchResults: any[] = [];
 

  constructor(private bookservice:BookService) {}

  ngOnInit(): void {
    this.getBooks();
  }

  getBooks() {
    this.bookservice.getBooks().subscribe((data) => {
        this.searchResults = data;
      });
  }


  searchBooks(){
    if (this.input.trim() !== '') {
      this.bookservice.searchBooks(this.input).subscribe((data) => {
        this.searchResults = data;
      });
    }
  }



  






}
