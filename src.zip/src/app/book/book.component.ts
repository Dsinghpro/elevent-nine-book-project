import { Component } from '@angular/core';
import { BookService } from './book.service';
import { NgForm } from '@angular/forms'; 

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent {
  title: string = '';
  category:string='';
  searchResults: any[] = [];
 

  constructor(private bookservice:BookService) {}

  ngOnInit(): void {
    this.getBooks();
  }

  getBooks() {
    this.bookservice.getBooks().subscribe((data) => {
        this.searchResults = data;
      });
  }

  searchBooksByTitle() {
    if (this.title.trim() !== '') {
      this.bookservice.searchBooksByTitle(this.title).subscribe((data) => {
        this.searchResults = data;
      });
    }
  }

  searchBooksByCategory(){
    if (this.category.trim() !== '') {
      this.bookservice.searchBooksByCategory(this.category).subscribe((data) => {
        this.searchResults = data;
      });
    }
  }

}
