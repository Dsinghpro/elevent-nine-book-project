// book.service.ts
import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class BookService {
 
  private baseUrl1 = 'http://localhost:8088/book/title'; // Replace with your actual backend API URL

  private baseUrl2='http://localhost:8088/book/category';

  private baseUrl='http://localhost:8088/book/all';

  constructor(private http:HttpClient) {}
 


  searchBooksByTitle(title: string): Observable<any> {
    console.log(title);
    return this.http.get<any[]>(`${this.baseUrl1}/${title}`);
  
  }

  searchBooksByCategory(category: string) {
    console.log(category);
    return this.http.get<any[]>(`${this.baseUrl2}/${category}`);
  }

  getBooks(): Observable<any[]> {
   
    return this.http.get<any[]>(`${this.baseUrl}`);
  }



}
