import { Component } from "@angular/core";
import { SigninService } from "./signin.service";
import { NgForm } from "@angular/forms";
@Component({
    selector:'sign-in',
    templateUrl:'./signin.component.html',
    styleUrls: ['./signin.component.css']
})
export class SigninComponent {
    // Define properties to store user registration data
    

    constructor(private signinService: SigninService) {}

    registerUser(myForm:NgForm) {
        // Create an object to hold user registration data
       

        console.log(myForm.value);
        

        // Call the SigninService to register the user
        this.signinService.signInHere(myForm.value).subscribe(
            response => {
                // Handle successful registration response here
                console.log('User registered successfully', response);
                alert("Succesful registration")
                // Optionally, reset the form or navigate to a success page
               
            },
            error => {
                // Handle registration error here
                console.error('Error registering user', error);
            }
        );
    }
}