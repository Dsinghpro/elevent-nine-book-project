import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminhomepage',
  templateUrl: './adminhomepage.component.html',
  styleUrls: ['./adminhomepage.component.css']
})
export class AdminhomepageComponent {


    constructor(private router:Router){}
    redirecttoaddbook()
    {
        this.router.navigate(["/addbook"]);
    }
    redirecttoremovebook()
    {
        this.router.navigate(["/deletebook"]);
    }
    
  redirecttoViewCustomers(){
      this.router.navigate(['/customerdetails'])
  }
  
}
