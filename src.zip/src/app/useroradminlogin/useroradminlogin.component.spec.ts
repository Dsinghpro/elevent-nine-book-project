import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserorAdminLoginComponent } from './useroradminlogin.component';

describe('UseroradminloginComponent', () => {
  let component: UserorAdminLoginComponent;
  let fixture: ComponentFixture<UserorAdminLoginComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UserorAdminLoginComponent]
    });
    fixture = TestBed.createComponent(UserorAdminLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
