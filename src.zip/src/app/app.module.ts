import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SigninComponent } from './signin/signin.component';
import { HomeComponent } from './home/home.component';
import { CustomerHomepageComponent } from './homepage/homepage.component';
import { CustomerLoginComponent } from './CustomerLogin/customer-login.component';
import { CustomerLoginService } from './CustomerLogin/customer-login.service';
import { SigninService } from './signin/signin.service';
import { UserorAdminLoginComponent } from './useroradminlogin/useroradminlogin.component';

import { HttpClientModule } from '@angular/common/http';
import { AdminLoginComponent } from './adminlogin/adminlogin.component';
import { AdminLoginService } from './adminlogin/adminlogin.service';
import { FormsModule } from '@angular/forms';
import { BookComponent } from './book/book.component';
import { BookService } from './book/book.service';
import { AddBookComponent } from './addbook/addbook.component';
import { DeletebookComponent } from './deletebook/deletebook.component';
import { AdminhomepageComponent } from './adminhomepage/adminhomepage.component';
import { CustomerdetailsComponent } from './customerdetails/customerdetails.component';
import { OrderComponent } from './order/order.component';
import { CartComponent } from './cart/cart.component';
import { ProfileComponent } from './profile/profile.component';
import { ProfileService } from './profile/profile.service';




@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    CustomerHomepageComponent,
    UserorAdminLoginComponent,
    CustomerLoginComponent,
    SigninComponent,
    AdminLoginComponent,
    BookComponent,
    AddBookComponent,
    DeletebookComponent,
    AdminhomepageComponent,
    CustomerdetailsComponent,
    OrderComponent,
    CartComponent,
    ProfileComponent,
    

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,

  ],
  providers: [CustomerLoginService,SigninService,AdminLoginService,BookService,ProfileService],
  bootstrap: [AppComponent]
})
export class AppModule { }
