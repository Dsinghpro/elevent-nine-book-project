package com.example.OnlineBookStore.controller;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.OnlineBookStore.entity.AdminLogin;

import com.example.OnlineBookStore.repository.AdminLoginRepository;

@CrossOrigin
@RestController
@RequestMapping("/admin")
public class AdminLoginController {
	
	private final AdminLoginRepository adminloginRepository;

	
	@Autowired
	public AdminLoginController(AdminLoginRepository adminloginRepository) {
		this.adminloginRepository=adminloginRepository;
	}
	
	@GetMapping("/all")
	public List<AdminLogin> getAllAdmin(){
		return adminloginRepository.findAll();
	}
	
	
	@PostMapping("/Adminsignup")
	public AdminLogin createAdmin(@RequestBody AdminLogin adminlogin) {
		return adminloginRepository.save(adminlogin);
	}
	
	@PostMapping("/login")
	public int adminLogin(@RequestBody Map<String, String>map) {
		try {
			String loginName = map.get("loginName");
			String password = map.get("password");
			
			AdminLogin adminLogin =  adminloginRepository.adminlogin(loginName, password);
			
			
			if (Objects.isNull(adminLogin)) {
				return 0;
			} else {
				return 1;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	

}
