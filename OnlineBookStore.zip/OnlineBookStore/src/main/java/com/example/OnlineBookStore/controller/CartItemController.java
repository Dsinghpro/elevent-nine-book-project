package com.example.OnlineBookStore.controller;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.OnlineBookStore.entity.CartItem;
import com.example.OnlineBookStore.entity.CustomerRegistration;
import com.example.OnlineBookStore.repository.BooksRepository;
import com.example.OnlineBookStore.repository.CartItemRepository;
import com.example.OnlineBookStore.repository.CustomerRegistrationRepository;

@RestController
@RequestMapping("/cart")
public class CartItemController {
	
	
	private final CartItemRepository cartitemRepository;
	
	@Autowired
	BooksRepository booksRepository;
	
	
	@Autowired
	CustomerRegistrationRepository customerRegistrationRepository;
	
	@Autowired
	public CartItemController(CartItemRepository cartItemRepository) {
		this.cartitemRepository=cartItemRepository;
	}
	
	@GetMapping("/all")
	public List<CartItem> getAllcartitem(){
		return cartitemRepository.findAll();
	}
	
	@PostMapping("/insertcart")
	public ResponseEntity<String> insertintoCart(@RequestBody Map<String, String> map) {
		
		CartItem cartItem = cartitemRepository.findCartItemBycustomerRegistration(customerRegistrationRepository.findById(Integer.parseInt(map.get("Custid"))).get().getCustomerRegistrationId(), booksRepository.findById(Integer.parseInt(map.get("bookID"))).get().getBookId());
		if (Objects.isNull(cartItem)) {
			CartItem ci = new CartItem();
			ci.setBook(booksRepository.findById(Integer.parseInt(map.get("bookID"))).get());
			ci.setCustomerRegistration(customerRegistrationRepository.findById(Integer.parseInt(map.get("Custid"))).get());
			ci.setQuantity(1);
			cartitemRepository.save(ci);
			return new ResponseEntity<String>("Item Added", HttpStatus.OK);
		}else if (Objects.isNull(cartItem) == false) {
		cartItem.setQuantity(cartItem.getQuantity()+1);
		cartitemRepository.save(cartItem);
		return new ResponseEntity<String>("Item Modified", HttpStatus.OK);
		}
		return new ResponseEntity<String>("Something Went Wrong; Plis try after some time.", HttpStatus.INTERNAL_SERVER_ERROR);
	} 
	
	

}
