package com.example.OnlineBookStore.repository;



import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import com.example.OnlineBookStore.entity.Books;

public interface BooksRepository extends JpaRepository<Books,Integer>{

	
	@Query(nativeQuery = true,name = "select * from books where Title like %:title%")
    List<Books> searchBooksByTitle(String title);
	
	@Query(value = "SELECT * FROM Books WHERE author_id = :authorId", nativeQuery = true)
    Optional<Books> findBooksByAuthorId(@Param("authorId") int authorId);
	
//	 @Procedure("SearchBooksByAuthorName")
//	    List<Books> searchBooksByAuthorName(@Param("searchAuthorName") String searchAuthorName);
	
//	 @Query(nativeQuery = true,value = "select books.*,authors.* from books\r\n"
//	 		+ "join authors on authors.author_id = books.author_id where authors.author_name like %:authorName% ")
//	    List<Books> searchBooksByAuthorName(String authorName);
	
	
	
	
//	@Procedure(name = "InsertBook")
//    String insertBook(
//        @Param("p_AuthorId") int  authorId,
//        @Param("p_PublicationId") int publicationId,
//        @Param("p_Title") String title,
//        @Param("p_ISBN") String isbn,
//        @Param("p_Category") String category,
//        @Param("p_publicationYear") Integer publicationYear,
//        @Param("p_price") Float price,
//        @Param("p_quantity") Integer quantity
//    );
//	
	@Query(nativeQuery = true,name = "select * from books where category=:searchCategory")
    List<Books> searchBooksByCategory(@Param("searchCategory") String searchCategory);

	}


