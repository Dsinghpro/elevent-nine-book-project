package com.example.OnlineBookStore.repository;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.OnlineBookStore.entity.CartItem;

public interface CartItemRepository extends JpaRepository<CartItem,Integer>{

	@Query(nativeQuery = true,value = "select * from cart where customer_registration_id= :customerRegistration and book_id=:book")
	 CartItem findCartItemBycustomerRegistration(@Param("customerRegistration") int customerRegistration,int book);
	
	

}
